1. run OpenSees
2. OpenSees-> sour server.tcl
3. run another OpenSees
4. OpenSees-> sour client.tcl